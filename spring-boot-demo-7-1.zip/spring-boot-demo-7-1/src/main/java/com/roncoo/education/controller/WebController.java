package com.roncoo.education.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author: ZouTai
 * @date: 2018/2/24
 * @description:
 */
@Controller
@RequestMapping("/web")
public class WebController {

    private static final Logger logger = LoggerFactory.getLogger(WebController.class);

    @RequestMapping("/index")
    public String index(ModelMap map) {
        map.put("title", "首页");
        // 返回一个视图，在template中（找index.ftl）
        return "index";
    }
}
