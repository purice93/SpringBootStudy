package com.roncoo.example;

import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.cache.annotation.EnableCaching;

//第三种方式
// 方法三 ：在 SpringBootApplication 上使用@ServletComponentScan
// 然后分别加上@WebFilter、@WebListener、@WebServlet
//@WebFilter(urlPatterns = "/roncoo")
//@WebListener
//@WebServlet(urlPatterns = "/roncoo", name = "CustomServlet")

@EnableRabbit
//@EnableJms
@EnableCaching
@ServletComponentScan
@SpringBootApplication
public class SpringBootDemo101Application {
    public static void main(String[] args) {
        SpringApplication.run(SpringBootDemo101Application.class, args);
    }
}


////第二种方式
//@SpringBootApplication
//public class SpringBootDemo101Application implements ServletContextInitializer {
//
//    @Override
//    public void onStartup(ServletContext servletContext) throws ServletException {
//        servletContext.addServlet("customServlet", new CustomServlet()).addMapping("/roncoo");
//        servletContext.addFilter("customFilter", new CustomFilter()).addMappingForServletNames(EnumSet.of(DispatcherType.REQUEST), true, "customServlet");
//        servletContext.addListener(new CustomListener());
//    }
//
//    public static void main(String[] args) {
//        SpringApplication.run(SpringBootDemo101Application.class, args);
//    }
//}



//第一种方式
//@SpringBootApplication
//public class SpringBootDemo101Application {
//
//    // 只拦截servletRegistrationBean，即/roncoo
//	@Bean
//    public FilterRegistrationBean filterRegistrationBean() {
//        return new FilterRegistrationBean(new CustomFilter(), servletRegistrationBean());
//    }
//
////    // 拦截全局
////    @Bean
////    public FilterRegistrationBean filterRegistrationBean2() {
////        return new FilterRegistrationBean(new CustomFilter());
////    }
//
//	@Bean
//	public ServletListenerRegistrationBean<CustomListener> servletListenerRegistrationBean() {
//		return new ServletListenerRegistrationBean<CustomListener>(new CustomListener());
//	}
//
//
//	@Bean
//	public ServletRegistrationBean servletRegistrationBean() {
//		return new ServletRegistrationBean(new CustomServlet(), "/roncoo");
//	}
//
//	public static void main(String[] args) {
//		SpringApplication.run(SpringBootDemo101Application.class, args);
//	}
//}
