//package com.roncoo.example.util.configuratoin;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//
///**
// * jms 队列配置
// *
// * @author wujing
// */
//@Configuration
//public class JmsConfiguration {
//
//	@Bean
//    public Queue queue() {
//		return new ActiveMQQueue("roncoo.queue");
//	}
//
//}
